CREATE TABLE IF NOT EXISTS applications (
  id TEXT PRIMARY KEY,
  application_number TEXT NOT NULL UNIQUE,
  submitted_at TEXT NOT NULL DEFAULT (datetime('now')),
  student_name TEXT NOT NULL,
  father_guardian_name TEXT NOT NULL,
  date_of_birth TEXT NOT NULL,
  gender TEXT NOT NULL,
  cnic_bform TEXT NOT NULL,
  mobile_number TEXT NOT NULL,
  student_email TEXT,
  domicile TEXT,
  postal_address TEXT NOT NULL,
  program TEXT NOT NULL,
  shift TEXT,
  matric_total_marks TEXT NOT NULL,
  matric_obtained_marks TEXT NOT NULL,
  matric_percentage TEXT,
  matric_year TEXT,
  fsc_total_marks TEXT NOT NULL,
  fsc_obtained_marks TEXT NOT NULL,
  fsc_percentage TEXT,
  fsc_year TEXT,
  additional_information TEXT,
  declaration TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_applications_submitted_at ON applications(submitted_at);
CREATE INDEX IF NOT EXISTS idx_applications_cnic ON applications(cnic_bform);
CREATE INDEX IF NOT EXISTS idx_applications_program ON applications(program);
