KHYBER SCHOOL OF NURSING AND ALLIED HEALTH SCIENCE
Cloudflare Pages + D1 Admission Portal

WHAT THIS VERSION DOES
- Website is hosted on Cloudflare Pages.
- Admission submissions are handled by a Cloudflare Pages Function at /api/submit.
- Applications are stored in Cloudflare D1 instead of Netlify Forms.
- Each successful application receives a unique application number such as KSN-20260821-XXXXXXXX.
- The form works with JavaScript enabled and also has a normal POST action for fallback.
- CNA is correctly shown as: CNA 2 Years Diploma Program.

IMPORTANT
Cloudflare Pages Functions cannot be deployed by the normal Pages Direct Upload ZIP workflow. Cloudflare currently requires Git integration or Wrangler for a project that contains Functions.

SETUP
1. Create a Cloudflare Pages project connected to a GitHub repository containing this folder.
2. Build command: leave empty (or use: exit 0).
3. Build output directory: public
4. Create a Cloudflare D1 database named: khyber-admissions
5. Run schema.sql against that D1 database.
6. Bind the D1 database to the Pages project using the variable name:
   ADMISSIONS_DB
7. If using wrangler.toml, replace DATABASE_ID with your actual D1 database ID.
8. Deploy/redeploy the project.
9. Open /admission.html and submit a test application.

D1 SETUP (DASHBOARD METHOD)
Cloudflare Dashboard -> Workers & Pages -> D1 -> Create database.
Then open the Pages project -> Settings -> Bindings -> Add -> D1 database.
Variable name: ADMISSIONS_DB
Select the khyber-admissions database.
Redeploy after adding the binding.

SCHEMA
Use schema.sql in the Cloudflare D1 console to create the applications table.

IMPORTANT SECURITY NOTE
The database is not exposed directly to the public website. Students can only call POST /api/submit. The Function validates required fields and allowed programs before inserting the record.

PROGRAMS
- Generic BSN 4 Years Degree Program
- Post RN 2 Years Degree Program
- CNA 2 Years Diploma Program
- ICU Speciality 1 Years Diploma Program
- Midwifery 2 Years Diploma Program
