/**
 * Cloudflare Pages Function
 * POST /api/submit
 * Stores admission applications in Cloudflare D1.
 */

const requiredFields = [
  'student_name',
  'father_guardian_name',
  'date_of_birth',
  'gender',
  'cnic_bform',
  'mobile_number',
  'postal_address',
  'program',
  'matric_total_marks',
  'matric_obtained_marks',
  'fsc_total_marks',
  'fsc_obtained_marks',
  'declaration'
];

function clean(value) {
  return String(value ?? '').trim();
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=UTF-8',
      'Cache-Control': 'no-store'
    }
  });
}

function applicationNumber() {
  const now = new Date();
  const date = now.toISOString().slice(0, 10).replaceAll('-', '');
  const random = crypto.randomUUID().replaceAll('-', '').slice(0, 8).toUpperCase();
  return `KSN-${date}-${random}`;
}

export async function onRequestPost({ request, env }) {
  if (!env.ADMISSIONS_DB) {
    return json({
      success: false,
      message: 'The admission database is not connected yet. Please contact the administrator.'
    }, 503);
  }

  let form;
  try {
    form = await request.formData();
  } catch {
    return json({ success: false, message: 'Invalid form submission.' }, 400);
  }

  // Honeypot: bots that fill this hidden field are rejected silently.
  if (clean(form.get('bot_field'))) {
    return json({ success: false, message: 'Invalid submission.' }, 400);
  }

  const data = Object.fromEntries(
    [...form.entries()].map(([key, value]) => [key, clean(value)])
  );

  for (const field of requiredFields) {
    if (!data[field]) {
      return json({
        success: false,
        message: 'Please complete all required fields before submitting.'
      }, 400);
    }
  }

  if (data.gender !== 'Male' && data.gender !== 'Female') {
    return json({ success: false, message: 'Please select a valid gender.' }, 400);
  }

  const allowedPrograms = new Set([
    'Generic BSN 4 Years Degree Program',
    'Post RN 2 Years Degree Program',
    'CNA 2 Years Diploma Program',
    'ICU Speciality 1 Years Diploma Program',
    'Midwifery 2 Years Diploma Program'
  ]);
  if (!allowedPrograms.has(data.program)) {
    return json({ success: false, message: 'Please select a valid program.' }, 400);
  }

  const id = crypto.randomUUID();
  const appNo = applicationNumber();

  try {
    await env.ADMISSIONS_DB.prepare(`
      INSERT INTO applications (
        id, application_number, submitted_at,
        student_name, father_guardian_name, date_of_birth, gender,
        cnic_bform, mobile_number, student_email, domicile, postal_address,
        program, shift,
        matric_total_marks, matric_obtained_marks, matric_percentage, matric_year,
        fsc_total_marks, fsc_obtained_marks, fsc_percentage, fsc_year,
        additional_information, declaration
      ) VALUES (?, ?, datetime('now'), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      id, appNo,
      data.student_name,
      data.father_guardian_name,
      data.date_of_birth,
      data.gender,
      data.cnic_bform,
      data.mobile_number,
      data.student_email,
      data.domicile,
      data.postal_address,
      data.program,
      data.shift,
      data.matric_total_marks,
      data.matric_obtained_marks,
      data.matric_percentage,
      data.matric_year,
      data.fsc_total_marks,
      data.fsc_obtained_marks,
      data.fsc_percentage,
      data.fsc_year,
      data.additional_information,
      data.declaration
    ).run();
  } catch (error) {
    console.error('Admission insert failed:', error);
    return json({
      success: false,
      message: 'We could not save your application right now. Please try again in a moment.'
    }, 500);
  }

  return json({
    success: true,
    applicationNumber: appNo,
    message: 'Application submitted successfully.'
  });
}
